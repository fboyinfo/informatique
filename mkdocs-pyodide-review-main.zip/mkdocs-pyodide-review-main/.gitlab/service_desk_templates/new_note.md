Votre signalement %{ISSUE_ID} dans le projet %{ISSUE_PATH} est cours de traitement.

N'hésitez pas à répondre à ce courriel pour apporter des précisions à votre demande.

---
[Se désinscrire](%{UNSUBSCRIBE_URL})
