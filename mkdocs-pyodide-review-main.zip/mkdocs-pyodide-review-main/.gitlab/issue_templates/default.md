## Résumé de la remarque

(compléter ici un résumé de votre remarque)

## Étapes pour reproduire

(si nécessaire indiquer ici les étapes pour reproduire votre remarque)

## Comportement observé

(indiquer le comportement fautif observé)

## Comportement attendu

(indiquer ici le comportement attendu)

## Traces et captures d'écran

(ajouter toutes traces (fichier journal, capture de la console) nécessaires, ainsi que d'éventuelles captures d'écrans)

## Correctifs potentiels

(indiquer ici si vous disposez d'un correctif)

/label ~bug
