---
author: Votre nom
title: Premier élément d'une liste Python
tags:
  - 3-liste/tableau
---

La fonction `premier_liste` prend en paramètres une liste Python **non vide** et renvoie le premier élément de cette liste

???+ question "Compléter ci-dessous"

    {{ IDE('scripts/premier_liste') }}
