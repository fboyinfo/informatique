---
author: Votre nom
title: Une fonction
tags:
  - 2-fonction
---

La fonction `addition` prend en paramètres deux nombres entiers ou flottants, et renvoie la somme des deux.

???+ question "Compléter ci-dessous"

    {{ IDE('scripts/addition') }}
