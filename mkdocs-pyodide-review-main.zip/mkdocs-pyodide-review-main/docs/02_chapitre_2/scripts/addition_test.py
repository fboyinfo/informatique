# Tests
assert addition(2, 3) == 5

# Autres tests
assert addition(2458942644, 34894513287656) == 34896972230300