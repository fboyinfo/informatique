!!! info "Le rang 0"

    Le premier élément d'une liste est celui de rang 0.

    
