def premier(ma_liste):
    ...


# Tests
assert premier([8, 4, 6]) == 8