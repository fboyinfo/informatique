def premier(ma_liste):
    return ma_liste[0]

