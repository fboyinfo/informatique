# Tests
assert premier([8, 4, 6]) == 8

# Autres tests
assert premier([9, 4, 6, 15]) == 9
assert premier([200, 4, 6, 15]) == 200
