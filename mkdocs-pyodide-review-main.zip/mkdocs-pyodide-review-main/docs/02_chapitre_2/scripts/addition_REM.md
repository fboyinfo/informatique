!!! info "Paramètres"

    Lorsqu'on écrit `addition(a, b)` a et b s'appellent les **paramaètres** de la fonction `addition`
