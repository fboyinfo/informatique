def addition(a, b):
    ...

# tests
assert addition(2, 3) == 5

